package com.github.banu.impl;

import com.github.banu.model.Book;
import com.github.banu.service.BookService;

public class BookServiceSqlImpl implements BookService{

	@Override
	public void addBook(Book book) {
		System.out.println("SQL Store!!!");
	}

}
