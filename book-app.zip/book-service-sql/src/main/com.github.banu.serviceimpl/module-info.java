module com.github.banu.serviceimpl {
	requires com.github.banu.bookservice;
	provides com.github.banu.service.BookService with com.github.banu.impl.BookServiceSqlImpl;
}