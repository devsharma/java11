package com.github.banu.service;

import java.util.Optional;
import java.util.ServiceLoader;

import com.github.banu.model.Book;

public interface BookService {
	void addBook(Book book);
	
	public static Optional<BookService> getServiceInstance() {
		ServiceLoader<BookService> loader = ServiceLoader.load(BookService.class);
		return loader.findFirst();
	}
}
