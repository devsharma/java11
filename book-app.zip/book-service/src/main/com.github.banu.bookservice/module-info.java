module com.github.banu.bookservice {
	exports com.github.banu.model;
	exports com.github.banu.service;
	uses com.github.banu.service.BookService;
}