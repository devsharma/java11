package main;

import com.github.banu.model.Book;
import com.github.banu.service.BookService;

public class Main {

	public static void main(String[] args) {
		Book book = new Book();
		book.setTitle("A");
		BookService service = BookService.getServiceInstance().get();
		service.addBook(book);
	}

}
