module com.github.banu.ui {
	requires com.github.banu.bookservice;
}