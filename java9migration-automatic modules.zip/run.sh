java --module-path mods --add-modules java.sql --module main/com.example.main.Main

