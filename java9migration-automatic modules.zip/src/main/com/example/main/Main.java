package com.example.main;

import com.example.models.Person;
import com.example.models.Address;

import com.google.gson.*;
import java.util.List;

public class Main {
    public static void main(String [] args) {

    	Person p1 = new Person("100", "Rahul", 24);
    	Person p2 = new Person("101", "Swetha", 38);

 		p1.addAddress(new Address("123 Main Street", "Bengaluru", "Karnataka"));
 		p1.addAddress(new Address("45, 1st Cross", "Mayur Vihar", "Delhi"));

 		p2.addAddress(new Address("M G Road", "Bengaluru", "Karnataka"));

		List<Person> persons = List.of(p1,p2);
    	Gson gson = new GsonBuilder().setPrettyPrinting().create();
    	String jsonStr = gson.toJson(persons);
    	System.out.println(jsonStr);
  }
}

