module main {
    requires gson;
    requires models;
}
