module models {
    requires gson;
    exports com.example.models;
    opens com.example.models to gson;
}
