java --class-path lib/gson-2.8.1.jar:lib/person.jar  com.example.main.Main

